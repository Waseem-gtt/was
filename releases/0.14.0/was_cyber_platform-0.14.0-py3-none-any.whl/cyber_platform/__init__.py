"""Local research platform. Uploaded files are data, never executable plugins."""
__version__ = "0.14.0"
